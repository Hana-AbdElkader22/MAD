﻿using Blog.Core.DTos;
using Blog.Core.Interfaces;
using Blog.Core.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Blog.APIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategoryService _categoryService;
        public CategoriesController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }


        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var categories = await _categoryService.GetAllAsync();
                if (categories == null || !categories.Any())
                    return NotFound(new
                    {
                        StatusCode = StatusCodes.Status404NotFound,
                        Message = "No Categories Found!",
                        Data = new List<Category>()
                    });

                return Ok(new
                {
                    StatusCode = StatusCodes.Status200OK,
                    Message = "Categories retrieved successfully",
                    Data = categories
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    StatusCode = StatusCodes.Status500InternalServerError,
                    Message = "An Error Occured while retriving data",
                    Error = ex.Message
                });
            }
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var category = await _categoryService.GetByIdAsync(id);
                if (category == null)
                    return NotFound(new
                    {
                        StatusCode = StatusCodes.Status404NotFound,
                        Message = $"Category with ID {id} not found"
                    });

                return Ok(new
                {
                    StatusCode = StatusCodes.Status200OK,
                    Message = "Category retrieved successfully",
                    Data = category
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    StatusCode = StatusCodes.Status500InternalServerError,
                    Message = "An Error Occured while retriving data!",
                    Error = ex.Message
                });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Add(CategoryDTo DTo)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(new
                    {
                        Message = "Invalid Category Data!",
                        Errors = ModelState.Values
                                   .SelectMany(v => v.Errors)
                                   .Select(e => e.ErrorMessage),
                        StatusCode = StatusCodes.Status400BadRequest
                    });

                var category = await _categoryService.CreateAsync(DTo);
                return StatusCode(StatusCodes.Status201Created, new
                {
                    Message = "Category created successfully",
                    Data = category,
                    StatusCode = StatusCodes.Status201Created
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    StatusCode = StatusCodes.Status500InternalServerError,
                    Message = "An Error Occured while creating data!",
                    Error = ex.Message
                });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Edit(int id, CategoryDTo DTo)
        {
            try
            {
                var old = await _categoryService.GetByIdAsync(id);
                if (old == null)
                    return BadRequest(new
                    {
                        Message = $"Category with ID {id} not found",
                        StatusCode = StatusCodes.Status400BadRequest
                    });

                if (await _categoryService.UpdateAsync(id, DTo))
                    return Ok(new
                    {
                        Message = "Category updated successfully",
                        Data = await _categoryService.GetByIdAsync(id),
                        StatusCode = StatusCodes.Status200OK
                    });

                return NotFound(new
                {
                    Message = "Category not updated",
                    StatusCode = StatusCodes.Status404NotFound
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    StatusCode = StatusCodes.Status500InternalServerError,
                    Message = "An Error Occured while updating data!",
                    Error = ex.Message
                });
            }
        }


        [HttpPut]
        public async Task<IActionResult> Edit(CategoryDTo DTo)
        {
            try
            {
                var old = await _categoryService.GetByIdAsync(DTo.Id);
                if (old == null)
                    return BadRequest(new
                    {
                        Message = $"Category with ID {DTo.Id} not found",
                        StatusCode = StatusCodes.Status400BadRequest
                    });

                if (await _categoryService.UpdateAsync(DTo))
                    return Ok(new
                    {
                        Message = "Category updated successfully",
                        Data = await _categoryService.GetByIdAsync(DTo.Id),
                        StatusCode = StatusCodes.Status200OK
                    });

                return NotFound(new
                {
                    Message = "Category not updated",
                    StatusCode = StatusCodes.Status404NotFound
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    StatusCode = StatusCodes.Status500InternalServerError,
                    Message = "An Error Occured while updating data!",
                    Error = ex.Message
                });
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var category = await _categoryService.GetByIdAsync(id);
                if (category == null)
                    return NotFound(new
                    {
                        Message = "Category not found",
                        StatusCode = StatusCodes.Status404NotFound
                    });

                if (await _categoryService.DeleteAsync(id))
                    return Ok(new
                    {
                        Message = "Category deleted successfully",
                        OldData = category,
                        StatusCode = StatusCodes.Status200OK
                    });

                return BadRequest(new
                {
                    Message = "An Error Occured while deleting data!",
                    StatusCode = StatusCodes.Status400BadRequest
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    StatusCode = StatusCodes.Status500InternalServerError,
                    Message = "An Error Occured while deleting data!",
                    Error = ex.Message
                });
            }
        }
    }
}
