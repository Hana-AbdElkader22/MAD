//posts.js
// Populate posts table
function populatePostsTable() {
    const table = $('#posts-table').DataTable({
        data: posts,
        columns: [
            { data: 'id' },
            { data: 'title' },
            { 
                data: 'body',
                render: function(data) {
                    return data.length > 100 ? data.substring(0, 100) + '...' : data;
                }
            },
            { data: 'userId' },
            {
                data: null,
                render: function(data, type, row) {
                    return `
                        <div class="action-buttons">
                            <button class="btn btn-info btn-sm view-post" data-id="${row.id}">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-warning btn-sm edit-post" data-id="${row.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger btn-sm delete-post" data-id="${row.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        responsive: true,
        language: {
            search: "Search:",
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            paginate: {
                previous: "Previous",
                next: "Next"
            }
        }
    });
    
    // Handle post search
    $('#post-search').on('keyup', function() {
        table.search(this.value).draw();
    });
    
    // Handle post actions
    $('#posts-table').on('click', '.view-post', function() {
        const postId = $(this).data('id');
        const post = posts.find(p => p.id === postId);
        
        if (post) {
            // البحث عن اسم المستخدم
            const user = users.find(u => u.id === post.userId);
            const userName = user ? user.name : 'Unknown User';
            
            // إنشاء محتوى مفصل للإشعار
            const postInfo = `
                <div class="post-details">
                    <h5>${post.title}</h5>
                    <p><strong>Author:</strong> ${userName}</p>
                    <p>${post.body}</p>
                </div>
            `;
            
            // عرض الإشعار مع المحتوى المفصل
            toastr.info(postInfo, 'Post Details', {
                closeButton: true,
                timeOut: 15000, // 15 ثانية للمنشورات الطويلة
                extendedTimeOut: 5000,
                progressBar: true,
                newestOnTop: true
            });
        } else {
            toastr.error('Post not found', 'Error');
        }
    });
    
    $('#posts-table').on('click', '.edit-post', function() {
        const postId = $(this).data('id');
        const post = posts.find(p => p.id === postId);
        
        if (post) {
            toastr.warning(`Edit post: ${post.title} (ID: ${post.id})`, 'Edit Post');
        } else {
            toastr.error('Post not found', 'Error');
        }
    });
    
    $('#posts-table').on('click', '.delete-post', function() {
        const postId = $(this).data('id');
        const post = posts.find(p => p.id === postId);
        
        if (post) {
            if (confirm(`Are you sure you want to delete post: ${post.title}?`)) {
                // في تطبيق حقيقي، هنا سيكون هناك طلب DELETE إلى API
                toastr.error(`Post "${post.title}" has been deleted`, 'Post Deleted');
            }
        }
    });
    
    // Add new post button
    $('#add-post-btn').click(function() {
        toastr.success('Add new post clicked!');
    });
}