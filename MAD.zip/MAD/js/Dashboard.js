//dashboard.js
// Populate recent users table
function populateRecentUsers() {
    const recentUsers = users.slice(0, 5);
    let html = '';
    
    recentUsers.forEach(user => {
        html += `
            <tr>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.phone}</td>
                <td>${user.website}</td>
                <td>
                    <button class="btn btn-info btn-sm view-user" data-id="${user.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    $('#recent-users-table tbody').html(html);
    
    // Initialize DataTable for recent users
    $('#recent-users-table').DataTable({
        responsive: true,
        language: {
            search: "Search:",
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            paginate: {
                previous: "Previous",
                next: "Next"
            }
        }
    });
    
    // Handle view user action
    $('#recent-users-table').on('click', '.view-user', function() {
        const userId = $(this).data('id');
        const user = users.find(u => u.id === userId);
        
        if (user) {
            // إنشاء محتوى مفصل للإشعار
            const userInfo = `
                <div class="user-details">
                    <h5>${user.name} (@${user.username})</h5>
                    <p><strong>Email:</strong> ${user.email}</p>
                    <p><strong>Phone:</strong> ${user.phone}</p>
                    <p><strong>Website:</strong> ${user.website}</p>
                    <p><strong>Company:</strong> ${user.company.name}</p>
                    <p><strong>Address:</strong> ${user.address.street}, ${user.address.city}</p>
                </div>
            `;
            
            // عرض الإشعار مع المحتوى المفصل
            toastr.info(userInfo, 'User Details', {
                closeButton: true,
                timeOut: 10000, // 10 ثواني
                extendedTimeOut: 5000,
                progressBar: true,
                newestOnTop: true
            });
        } else {
            toastr.error('User not found', 'Error');
        }
    });
}