//script.js
// Global variables
let users = [];
let posts = [];
let comments = [];
let favorites = JSON.parse(localStorage.getItem('favorites')) || [];

$(document).ready(function() {
    // Initialize toastr options
    toastr.options = {
        closeButton: true,
        progressBar: true,
        positionClass: "toast-bottom-right",
        timeOut: 5000,
        extendedTimeOut: 2000,
        preventDuplicates: true
    };
    
    // Show loader
    $('.loader').show();
    
    // Simulate loading data
    setTimeout(() => {
        loadData();
    }, 1500);
    
    // Navigation
    $('.nav-link').on('click', function(e) {
        e.preventDefault();
        const section = $(this).data('section');
        $('.nav-link').removeClass('active');
        $(this).addClass('active');
        $('.section').removeClass('active');
        $(`#${section}`).addClass('active'); // ✅ fixed
    });
    
    // Dark mode toggle
    $('#darkModeSwitch').change(function() {
        $('body').toggleClass('dark-mode', this.checked);
        localStorage.setItem('darkMode', this.checked);
    });
    
    // Theme toggle button
    $('#theme-toggle').click(function() {
        const isDarkMode = $('body').hasClass('dark-mode');
        $('body').toggleClass('dark-mode', !isDarkMode);
        $('#darkModeSwitch').prop('checked', !isDarkMode);
        localStorage.setItem('darkMode', !isDarkMode);
    });
    
    // Check for saved dark mode preference
    if (localStorage.getItem('darkMode') === 'true') {
        $('#darkModeSwitch').prop('checked', true);
        $('body').addClass('dark-mode');
    }
    
    // Load data from APIs
    function loadData() {
        // Load users
        $.get('https://jsonplaceholder.typicode.com/users', function(data) {
            users = data;
            $('#users-count').text(users.length);
            populateUsersTable();
            populateRecentUsers();
        }).fail(function() {
            toastr.error('Failed to load users data');
        });
        
        // Load posts
        $.get('https://jsonplaceholder.typicode.com/posts', function(data) {
            posts = data;
            $('#posts-count').text(posts.length);
            populatePostsTable();
        }).fail(function() {
            toastr.error('Failed to load posts data');
        });
        
        // Load comments
        $.get('https://jsonplaceholder.typicode.com/comments', function(data) {
            comments = data;
            $('#comments-count').text(comments.length);
        }).fail(function() {
            toastr.error('Failed to load comments data');
        });
        
        // Update favorites count
        $('#favorites-count').text(favorites.length);
        
        // Hide loader
        $('.loader').fadeOut();
        
        // Show success message
        toastr.success('Data loaded successfully!');
    }
});

// Populate posts table
function populatePostsTable() {
    const table = $('#posts-table').DataTable({
        data: posts,
        columns: [
            { data: 'id' },
            { data: 'title' },
            { 
                data: 'body',
                render: function(data) {
                    return data.length > 100 ? data.substring(0, 100) + '...' : data;
                }
            },
            { data: 'userId' },
            {
                data: null,
                render: function(data, type, row) {
                    return `
                        <div class="action-buttons">
                            <button class="btn btn-info btn-sm view-post" data-id="${row.id}">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-warning btn-sm edit-post" data-id="${row.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger btn-sm delete-post" data-id="${row.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        responsive: true,
        language: {
            search: "Search:",
            lengthMenu: "Show MENU entries",
            info: "Showing START to END of TOTAL entries",
            paginate: {
                previous: "Previous",
                next: "Next"
            }
        }
    });
    
    // Handle post search
    $('#post-search').on('keyup', function() {
        table.search(this.value).draw();
    });
    
    // Handle post actions
    $('#posts-table').on('click', '.view-post', function() {
        const postId = $(this).data('id');
        const post = posts.find(p => p.id === postId);
        
        if (post) {
            // البحث عن اسم المستخدم
            const user = users.find(u => u.id === post.userId);
            const userName = user ? user.name : 'Unknown User';
            
            // إنشاء محتوى مفصل للإشعار
            const postInfo = `
                <div class="post-details">
                    <h5>${post.title}</h5>
                    <p><strong>Author:</strong> ${userName}</p>
                    <p>${post.body}</p>
                </div>
            `;
            
            // عرض الإشعار مع المحتوى المفصل
            toastr.info(postInfo, 'Post Details', {
                closeButton: true,
                timeOut: 15000, // 15 ثانية للمنشورات الطويلة
                extendedTimeOut: 5000,
                progressBar: true,
                newestOnTop: true
            });
        } else {
            toastr.error('Post not found', 'Error');
        }
    });
    
    $('#posts-table').on('click', '.edit-post', function() {
        const postId = $(this).data('id');
        const post = posts.find(p => p.id === postId);
        
        if (post) {
            toastr.warning(`Edit post: ${post.title} (ID: ${post.id})`, 'Edit Post'); // ✅ fixed
        } else {
            toastr.error('Post not found', 'Error');
        }
    });
    
    $('#posts-table').on('click', '.delete-post', function() {
        const postId = $(this).data('id');
        const post = posts.find(p => p.id === postId);
        
        if (post) {
            if (confirm(`Are you sure you want to delete post: ${post.title}?`)) { // ✅ fixed
                // في تطبيق حقيقي، هنا سيكون هناك طلب DELETE إلى API
                toastr.error(`Post "${post.title}" has been deleted`, 'Post Deleted'); // ✅ fixed
            }
        }
    });
    
    // Add new post button
 // handle post form submit
/*document.getElementById("postForm").addEventListener("submit", function(e) {
  e.preventDefault();

  let title = document.getElementById("postTitle").value;
  let content = document.getElementById("postContent").value;

  // هنا تضيفي البوست للجدول أو لأي Array بتستخدميه
  console.log("New Post:", title, content);

  // قفل المودال
  let modal = bootstrap.Modal.getInstance(document.getElementById("addPostModal"));
  modal.hide();

  // مسح الحقول
  this.reset();

  // إشعار نجاح
  toastr.success("Post added successfully!");
}); */

let postId = 1; // counter for IDs

document.getElementById("postForm").addEventListener("submit", function(e) {
  e.preventDefault();

  let title = document.getElementById("postTitle").value;
  let content = document.getElementById("postContent").value;

  // إنشاء صف جديد
  let table = document.getElementById("postsTable").querySelector("tbody");
  let newRow = document.createElement("tr");

  newRow.innerHTML = `
    <td>${postId++}</td>
    <td>${title}</td>
    <td>${content}</td>
    <td>
      <button class="btn btn-info btn-sm"><i class="fas fa-eye"></i></button>
      <button class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
      <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
    </td>
  `;

  table.appendChild(newRow);

  // قفل المودال
  let modal = bootstrap.Modal.getInstance(document.getElementById("addPostModal"));
  modal.hide();

  // مسح الحقول
  this.reset();

  // إشعار نجاح
  toastr.success("Post added successfully!");
});


}
