//users.js
// Populate users table
function populateUsersTable() {
    const table = $('#users-table').DataTable({
        data: users,
        columns: [
            { data: 'id' },
            { data: 'name' },
            { data: 'username' },
            { data: 'email' },
            { data: 'phone' },
            { data: 'website' },
            {
                data: null,
                render: function(data, type, row) {
                    const isFavorite = favorites.includes(row.id);
                    return `<i class="fas fa-star star ${isFavorite ? 'favorite' : ''}" data-id="${row.id}"></i>`;
                }
            },
            {
                data: null,
                render: function(data, type, row) {
                    return `
                        <div class="action-buttons">
                            <button class="btn btn-info btn-sm view-user" data-id="${row.id}">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-warning btn-sm edit-user" data-id="${row.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger btn-sm delete-user" data-id="${row.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        responsive: true,
        language: {
            search: "Search:",
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            paginate: {
                previous: "Previous",
                next: "Next"
            }
        }
    });
    
    // Handle favorite toggle
    $('#users-table').on('click', '.star', function() {
        const userId = $(this).data('id');
        const index = favorites.indexOf(userId);
        
        if (index === -1) {
            favorites.push(userId);
            $(this).addClass('favorite');
            toastr.success('Added to favorites!');
        } else {
            favorites.splice(index, 1);
            $(this).removeClass('favorite');
            toastr.info('Removed from favorites!');
        }
        
        localStorage.setItem('favorites', JSON.stringify(favorites));
        $('#favorites-count').text(favorites.length);
    });
    
    // Handle user actions
    $('#users-table').on('click', '.view-user', function() {
        const userId = $(this).data('id');
        const user = users.find(u => u.id === userId);
        
        if (user) {
            // إنشاء محتوى مفصل للإشعار
            const userInfo = `
                <div class="user-details">
                    <h5>${user.name} (@${user.username})</h5>
                    <p><strong>Email:</strong> ${user.email}</p>
                    <p><strong>Phone:</strong> ${user.phone}</p>
                    <p><strong>Website:</strong> ${user.website}</p>
                    <p><strong>Company:</strong> ${user.company.name}</p>
                    <p><strong>Address:</strong> ${user.address.street}, ${user.address.city}</p>
                </div>
            `;
            
            // عرض الإشعار مع المحتوى المفصل
            toastr.info(userInfo, 'User Details', {
                closeButton: true,
                timeOut: 10000, // 10 ثواني
                extendedTimeOut: 5000,
                progressBar: true,
                newestOnTop: true
            });
        } else {
            toastr.error('User not found', 'Error');
        }
    });
    
    $('#users-table').on('click', '.edit-user', function() {
        const userId = $(this).data('id');
        const user = users.find(u => u.id === userId);
        
        if (user) {
            toastr.warning(`Edit user: ${user.name} (ID: ${user.id})`, 'Edit User');
        } else {
            toastr.error('User not found', 'Error');
        }
    });
    
    $('#users-table').on('click', '.delete-user', function() {
        const userId = $(this).data('id');
        const user = users.find(u => u.id === userId);
        
        if (user) {
            if (confirm(`Are you sure you want to delete user: ${user.name}?`)) {
                // في تطبيق حقيقي، هنا سيكون هناك طلب DELETE إلى API
                toastr.error(`User "${user.name}" has been deleted`, 'User Deleted');
            }
        }
    });
}